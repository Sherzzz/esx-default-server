fx_version 'adamant'

game 'gta5'

description 'Async'

server_script 'async.lua'
client_script 'async.lua'
