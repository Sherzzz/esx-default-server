fx_version 'adamant'

game 'gta5'

description 'ESX License'

version '1.0.1'

server_scripts {
	'@async/async.lua',
	'@mysql-async/lib/MySQL.lua',
	'server/main.lua'
}
