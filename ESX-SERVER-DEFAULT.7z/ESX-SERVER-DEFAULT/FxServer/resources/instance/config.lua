Config = {}

Config.Locale = 'fr'